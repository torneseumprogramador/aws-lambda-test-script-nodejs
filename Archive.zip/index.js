const axios = require('axios')

exports.executa_teste = async (event) => {
    
    axios.get('https://www.torneseumprogramador.com.br/?q=' + escape(JSON.stringify(event))).then(res => {
        console.log(`statusCode: ${res.status}`)
        console.log(res)
    }).catch(error => {
        console.error(error)
    })
      
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda! - ' + "Key1: " + event.key1 + " ----- "  + JSON.stringify(event)),
    };
    return response;
};
